export type Tab = "overview" | "model" | "pipeline" | "stage1" | "stage2" | "results" | "code";

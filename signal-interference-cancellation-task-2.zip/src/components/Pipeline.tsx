import Card from "./ui/Card";
import SectionTitle from "./ui/SectionTitle";

export default function Pipeline() {
  return (
    <div className="space-y-8">
      <SectionTitle
        title="Cancellation Pipeline"
        subtitle="A two-stage sequential pipeline that first removes TX-driven nonlinear interference, then eliminates the rank-1 external source."
      />

      {/* Main pipeline diagram */}
      <Card>
        <h3 className="text-lg font-semibold text-white mb-8 flex items-center gap-2">
          <span>🔧</span> Two-Stage Architecture
        </h3>

        <div className="relative">
          {/* Pipeline flow */}
          <div className="flex flex-col gap-0">

            {/* Input */}
            <div className="flex items-center gap-4 mb-2">
              <div className="w-32 shrink-0" />
              <div className="flex-1 bg-red-500/10 border border-red-500/30 rounded-xl p-4 text-center">
                <div className="text-red-400 font-bold font-mono text-lg">rx[n, c]</div>
                <div className="text-gray-400 text-xs mt-1">Corrupted received signal (N×4 complex)</div>
                <div className="flex justify-center gap-4 mt-3">
                  <SignalTag label="s[n,c]" color="bg-emerald-500/10 text-emerald-400 border-emerald-500/20" />
                  <SignalTag label="F_c(TX)" color="bg-yellow-500/10 text-yellow-400 border-yellow-500/20" />
                  <SignalTag label="E[n,c]" color="bg-purple-500/10 text-purple-400 border-purple-500/20" />
                  <SignalTag label="η" color="bg-gray-500/10 text-gray-400 border-gray-500/20" />
                </div>
              </div>
            </div>

            {/* Arrow down */}
            <div className="flex items-center gap-4 my-1">
              <div className="w-32 shrink-0" />
              <div className="flex-1 flex justify-center">
                <div className="w-0.5 h-8 bg-gradient-to-b from-red-500/50 to-yellow-500/50" />
              </div>
            </div>

            {/* Stage 1 */}
            <div className="flex items-stretch gap-4">
              <div className="w-32 shrink-0 flex items-center justify-end">
                <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-3 text-right">
                  <div className="text-yellow-400 font-bold text-sm">Stage 1</div>
                  <div className="text-gray-500 text-xs">TX Nonlinear</div>
                </div>
              </div>
              <div className="flex-1 bg-yellow-500/5 border border-yellow-500/30 rounded-xl p-5">
                <div className="text-yellow-400 font-semibold mb-3">Extended IMD3 Canceller</div>
                <div className="grid md:grid-cols-3 gap-3 text-sm">
                  <StageDetail
                    icon="📐"
                    title="30 IMD3 terms"
                    desc="All 15 TX pairs × 2 monomials each"
                  />
                  <StageDetail
                    icon="⏱️"
                    title="±10 lag taps"
                    desc="21 temporal lags per term → 630 features"
                  />
                  <StageDetail
                    icon="🎯"
                    title="Per-channel OLS"
                    desc="Trace-normalized Tikhonov regularization"
                  />
                </div>
                <div className="mt-3 font-mono text-xs text-gray-400">
                  <span className="text-white">rx₁</span> = rx − X·(XᴴX + λI)⁻¹·Xᴴ·y
                </div>
              </div>
            </div>

            {/* Arrow down with label */}
            <div className="flex items-center gap-4 my-1">
              <div className="w-32 shrink-0" />
              <div className="flex-1 flex justify-center items-center gap-3">
                <div className="flex flex-col items-center">
                  <div className="w-0.5 h-4 bg-gradient-to-b from-yellow-500/50 to-cyan-500/50" />
                  <div className="text-xs text-gray-500 my-1">F_c(TX) removed</div>
                  <div className="w-0.5 h-4 bg-gradient-to-b from-yellow-500/50 to-cyan-500/50" />
                </div>
              </div>
            </div>

            {/* Intermediate state */}
            <div className="flex items-center gap-4 mb-1">
              <div className="w-32 shrink-0" />
              <div className="flex-1 bg-gray-800/40 border border-gray-700 rounded-xl p-3 text-center">
                <div className="text-gray-300 font-mono font-semibold">rx₁[n, c]</div>
                <div className="flex justify-center gap-4 mt-2">
                  <SignalTag label="s[n,c]" color="bg-emerald-500/10 text-emerald-400 border-emerald-500/20" />
                  <SignalTag label="E[n,c]" color="bg-purple-500/10 text-purple-400 border-purple-500/20" />
                  <SignalTag label="η" color="bg-gray-500/10 text-gray-400 border-gray-500/20" />
                </div>
              </div>
            </div>

            {/* Arrow down */}
            <div className="flex items-center gap-4 my-1">
              <div className="w-32 shrink-0" />
              <div className="flex-1 flex justify-center">
                <div className="w-0.5 h-8 bg-gradient-to-b from-cyan-500/50 to-purple-500/50" />
              </div>
            </div>

            {/* Stage 2 */}
            <div className="flex items-stretch gap-4">
              <div className="w-32 shrink-0 flex items-center justify-end">
                <div className="bg-purple-500/10 border border-purple-500/30 rounded-xl p-3 text-right">
                  <div className="text-purple-400 font-bold text-sm">Stage 2</div>
                  <div className="text-gray-500 text-xs">Rank-1 Spatial</div>
                </div>
              </div>
              <div className="flex-1 bg-purple-500/5 border border-purple-500/30 rounded-xl p-5">
                <div className="text-purple-400 font-semibold mb-3">Rank-1 External Interference Canceller</div>
                <div className="grid md:grid-cols-3 gap-3 text-sm">
                  <StageDetail
                    icon="📊"
                    title="PCA extraction"
                    desc="Dominant eigenvector of band-filtered cross-channel covariance"
                  />
                  <StageDetail
                    icon="🔗"
                    title="Shared waveform"
                    desc="e[n] = R[n,:]·u from leading eigenvector u"
                  />
                  <StageDetail
                    icon="✂️"
                    title="Per-channel subtraction"
                    desc="α_c = ⟨e, r[:,c]⟩/‖e‖² → subtract α_c·e[n]"
                  />
                </div>
                <div className="mt-3 font-mono text-xs text-gray-400">
                  <span className="text-white">rx̂</span> = rx₁ − α·eᴴ    where C·u = λ_max·u
                </div>
              </div>
            </div>

            {/* Arrow down */}
            <div className="flex items-center gap-4 my-1">
              <div className="w-32 shrink-0" />
              <div className="flex-1 flex justify-center items-center gap-3">
                <div className="flex flex-col items-center">
                  <div className="w-0.5 h-4 bg-gradient-to-b from-purple-500/50 to-emerald-500/50" />
                  <div className="text-xs text-gray-500 my-1">E[n,c] removed</div>
                  <div className="w-0.5 h-4 bg-gradient-to-b from-purple-500/50 to-emerald-500/50" />
                </div>
              </div>
            </div>

            {/* Output */}
            <div className="flex items-center gap-4">
              <div className="w-32 shrink-0" />
              <div className="flex-1 bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-4 text-center">
                <div className="text-emerald-400 font-bold font-mono text-lg">rx̂[n, c]</div>
                <div className="text-gray-400 text-xs mt-1">Cleaned signal — interference cancelled</div>
                <div className="flex justify-center gap-4 mt-3">
                  <SignalTag label="s[n,c]" color="bg-emerald-500/10 text-emerald-400 border-emerald-500/20" />
                  <SignalTag label="η" color="bg-gray-500/10 text-gray-400 border-gray-500/20" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Validity proof */}
      <Card>
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <span>✅</span> Validity by Construction
        </h3>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-3">
            <div className="text-sm font-semibold text-emerald-400">Why the solution passes validity</div>
            <div className="bg-gray-800/60 rounded-lg p-4 border border-emerald-500/20 text-sm text-gray-300">
              <div className="font-semibold text-white mb-2">Removed component = TX + Rank-1</div>
              <div className="space-y-2 text-gray-400">
                <div>• <strong className="text-yellow-400">Stage 1</strong> removes exactly the TX-predicted OLS projection → 100% TX-explained</div>
                <div>• <strong className="text-purple-400">Stage 2</strong> removes exactly the rank-1 PCA component → passes residual_guard</div>
                <div>• Together: explain_ratio ≥ 0.95 satisfied by design</div>
              </div>
            </div>
          </div>
          <div className="space-y-3">
            <div className="text-sm font-semibold text-amber-400">What would make it invalid</div>
            <div className="bg-gray-800/60 rounded-lg p-4 border border-amber-500/20 text-sm text-gray-300">
              <div className="font-semibold text-white mb-2">Scenarios that fail the check</div>
              <div className="space-y-2 text-gray-400">
                <div>• Subtracting noise or desired signal s[n,c] — not explainable as TX or rank-1</div>
                <div>• Using a full-rank spatial canceller — residual_guard fails</div>
                <div>• Over-subtraction: err_power &gt; 0.80 × residual_power per channel</div>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Computation complexity */}
      <Card>
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <span>⚙️</span> Computational Complexity
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-700">
                <th className="text-left py-2 px-4 text-gray-400 font-medium">Step</th>
                <th className="text-left py-2 px-4 text-gray-400 font-medium">Complexity</th>
                <th className="text-left py-2 px-4 text-gray-400 font-medium">Dominant cost</th>
              </tr>
            </thead>
            <tbody>
              {[
                { step: "Build IMD3 terms (30×)", cost: "O(30·N·logN)", dominant: "Bandpass filtering via FFT-conv" },
                { step: "Build design matrix", cost: "O(30·21·N_sub)", dominant: "N_sub = 200,000 samples" },
                { step: "Gram matrix XᴴX", cost: "O(630²·N_sub)", dominant: "Matrix multiply (BLAS)" },
                { step: "Solve OLS per channel", cost: "O(630³ + 630²·N)", dominant: "Cholesky decomposition" },
                { step: "Apply model (Stage 1)", cost: "O(30·21·N)", dominant: "Shift + accumulate" },
                { step: "Band-filter residual", cost: "O(4·N·logN)", dominant: "FFT bandpass" },
                { step: "PCA (Stage 2)", cost: "O(4²·N + 4³)", dominant: "Cross-covariance matrix" },
                { step: "Rank-1 subtraction", cost: "O(4·N)", dominant: "Vector projection" },
              ].map((row, i) => (
                <tr key={i} className="border-b border-gray-800 hover:bg-gray-800/30">
                  <td className="py-2 px-4 font-mono text-xs text-gray-300">{row.step}</td>
                  <td className="py-2 px-4 font-mono text-xs text-cyan-400">{row.cost}</td>
                  <td className="py-2 px-4 text-xs text-gray-500">{row.dominant}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

function SignalTag({ label, color }: { label: string; color: string }) {
  return (
    <span className={`px-2 py-0.5 rounded border text-xs font-mono ${color}`}>
      {label}
    </span>
  );
}

function StageDetail({ icon, title, desc }: { icon: string; title: string; desc: string }) {
  return (
    <div className="bg-gray-900/60 rounded-lg p-3 border border-gray-700/50">
      <div className="text-lg mb-1">{icon}</div>
      <div className="text-white text-xs font-semibold mb-1">{title}</div>
      <div className="text-gray-400 text-xs">{desc}</div>
    </div>
  );
}

import Card from "./ui/Card";
import SectionTitle from "./ui/SectionTitle";

const TX_PAIRS = [
  { a: 0, b: 1, type: "Within block", level: "High × High", color: "cyan" },
  { a: 2, b: 3, type: "Within block", level: "Med × Med", color: "indigo" },
  { a: 4, b: 5, type: "Within block", level: "Low × Low", color: "violet" },
  { a: 0, b: 3, type: "Cross level/carrier", level: "High-A × Med-B", color: "yellow" },
  { a: 1, b: 2, type: "Cross level/carrier", level: "High-B × Med-A", color: "yellow" },
  { a: 0, b: 5, type: "Cross level/carrier", level: "High-A × Low-B ⭐", color: "yellow" },
  { a: 1, b: 4, type: "Cross level/carrier", level: "High-B × Low-A", color: "yellow" },
  { a: 2, b: 5, type: "Cross level/carrier", level: "Med-A × Low-B", color: "amber" },
  { a: 3, b: 4, type: "Cross level/carrier", level: "Med-B × Low-A", color: "amber" },
  { a: 0, b: 4, type: "Same carrier cross", level: "High-A × Low-A", color: "orange" },
  { a: 1, b: 5, type: "Same carrier cross", level: "High-B × Low-B", color: "orange" },
  { a: 0, b: 2, type: "Same carrier cross", level: "High-A × Med-A", color: "orange" },
  { a: 1, b: 3, type: "Same carrier cross", level: "High-B × Med-B", color: "orange" },
  { a: 2, b: 4, type: "Same carrier cross", level: "Med-A × Low-A", color: "red" },
  { a: 3, b: 5, type: "Same carrier cross", level: "Med-B × Low-B", color: "red" },
];

const colorMap: Record<string, string> = {
  cyan: "bg-cyan-500/10 text-cyan-400 border-cyan-500/20",
  indigo: "bg-indigo-500/10 text-indigo-400 border-indigo-500/20",
  violet: "bg-violet-500/10 text-violet-400 border-violet-500/20",
  yellow: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
  amber: "bg-amber-500/10 text-amber-400 border-amber-500/20",
  orange: "bg-orange-500/10 text-orange-400 border-orange-500/20",
  red: "bg-red-500/10 text-red-400 border-red-500/20",
};

export default function Stage1() {
  return (
    <div className="space-y-8">
      <SectionTitle
        title="Stage 1: Extended TX Nonlinear Canceller"
        subtitle="An extended IMD3 model with all 15 TX column pairs and wider temporal lags outperforms the baseline's 10-term, ±6-lag model."
      />

      {/* Comparison baseline vs ours */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card className="border-gray-600/50">
          <h3 className="text-base font-semibold text-gray-400 mb-4 flex items-center gap-2">
            <span>📦</span> Baseline Model
          </h3>
          <div className="space-y-3">
            <MetricRow label="IMD3 terms" value="10" note="subset of pairs" valueColor="text-gray-400" />
            <MetricRow label="Lag window" value="±6 taps" note="13 lags/term" valueColor="text-gray-400" />
            <MetricRow label="Total features" value="130" note="per RX channel" valueColor="text-gray-400" />
            <MetricRow label="Regularization" value="λ = 1e-6·I" note="fixed" valueColor="text-gray-400" />
            <MetricRow label="Expected score" value="~4 dB" note="" valueColor="text-yellow-400" />
          </div>
        </Card>

        <Card className="border-cyan-500/30">
          <h3 className="text-base font-semibold text-cyan-400 mb-4 flex items-center gap-2">
            <span>🚀</span> Extended Model (Ours)
          </h3>
          <div className="space-y-3">
            <MetricRow label="IMD3 terms" value="30" note="all 15 pairs × 2" valueColor="text-cyan-400" />
            <MetricRow label="Lag window" value="±10 taps" note="21 lags/term" valueColor="text-cyan-400" />
            <MetricRow label="Total features" value="630" note="per RX channel" valueColor="text-cyan-400" />
            <MetricRow label="Regularization" value="λ = trace-norm" note="adaptive" valueColor="text-cyan-400" />
            <MetricRow label="Expected score" value="> 8 dB" note="combined with Stage 2" valueColor="text-emerald-400" />
          </div>
        </Card>
      </div>

      {/* All 15 pairs */}
      <Card>
        <h3 className="text-lg font-semibold text-white mb-2 flex items-center gap-2">
          <span>🔗</span> All 15 TX Pair IMD3 Terms
        </h3>
        <p className="text-gray-400 text-sm mb-6">
          Each pair (a, b) generates two monomials: <span className="font-mono text-cyan-400">a²·b*</span> and{" "}
          <span className="font-mono text-cyan-400">b²·a*</span>. The baseline only uses 5 of 15 pairs (starred ⭐).
        </p>

        <div className="grid md:grid-cols-3 gap-3">
          {TX_PAIRS.map((pair, i) => (
            <div
              key={i}
              className={`rounded-xl border p-3 ${colorMap[pair.color]}`}
            >
              <div className="flex justify-between items-start mb-2">
                <div className="font-mono text-sm font-bold">
                  tx[:,{pair.a}] × tx[:,{pair.b}]
                </div>
                <span className="text-xs opacity-70">#{i + 1}</span>
              </div>
              <div className="text-xs opacity-80 mb-1">{pair.level}</div>
              <div className="text-xs opacity-60">{pair.type}</div>
              <div className="flex gap-2 mt-2">
                <span className="text-xs font-mono opacity-70">a²b*</span>
                <span className="text-xs font-mono opacity-70">b²a*</span>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Lag window visualization */}
      <Card>
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <span>⏱️</span> Temporal Lag Window
        </h3>
        <p className="text-gray-400 text-sm mb-6">
          Hardware delays, filter group delays, and propagation effects shift the interference by
          multiple samples. The lag window captures these offsets.
        </p>

        <div className="relative h-24 bg-gray-800/60 rounded-xl border border-gray-700 overflow-hidden px-4 pt-4">
          <div className="flex h-full items-end gap-0.5 justify-center">
            {Array.from({ length: 27 }, (_, i) => {
              const lag = i - 13;
              const inBaseline = lag >= -6 && lag <= 6;
              const inExtended = lag >= -10 && lag <= 10;
              const height = inExtended
                ? inBaseline
                  ? 80
                  : 55
                : 15;
              return (
                <div
                  key={i}
                  className={`w-4 rounded-t transition-all ${
                    inBaseline
                      ? "bg-yellow-500"
                      : inExtended
                      ? "bg-cyan-500/70"
                      : "bg-gray-700"
                  }`}
                  style={{ height: `${height}%` }}
                  title={`Lag ${lag}`}
                />
              );
            })}
          </div>
          <div className="absolute bottom-1 left-4 text-xs text-gray-500">−13</div>
          <div className="absolute bottom-1 right-4 text-xs text-gray-500">+13</div>
          <div className="absolute bottom-1 left-1/2 -translate-x-1/2 text-xs text-gray-400">0</div>
        </div>
        <div className="flex gap-4 mt-3 text-xs">
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded bg-yellow-500" />
            <span className="text-gray-400">Baseline (±6)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded bg-cyan-500/70" />
            <span className="text-gray-400">Extended only (±7 to ±10)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded bg-gray-700" />
            <span className="text-gray-400">Not used</span>
          </div>
        </div>
        <div className="mt-4 text-xs text-gray-500">
          At Fs = 7.68 MHz, ±10 samples = ±1.30 µs. This covers realistic cable delays and filter group delays.
        </div>
      </Card>

      {/* OLS algorithm */}
      <Card>
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <span>📐</span> OLS Regression Algorithm
        </h3>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <div className="text-sm text-gray-400 mb-3">Regression formulation (per RX channel c):</div>
            <div className="bg-gray-800/60 rounded-xl p-4 border border-gray-700 font-mono text-sm space-y-2">
              <div><span className="text-gray-500">// Design matrix (window)</span></div>
              <div><span className="text-cyan-400">X</span> <span className="text-gray-300">∈ ℂ^(N_sub × 630)</span></div>
              <div className="mt-2"><span className="text-gray-500">// Target: band-filtered RX</span></div>
              <div><span className="text-yellow-400">y</span> <span className="text-gray-300">= bandpass(rx[window, c])</span></div>
              <div className="mt-2"><span className="text-gray-500">// Regularized normal equations</span></div>
              <div><span className="text-gray-300">G = Xᴴ<span className="text-cyan-400">X</span> + <span className="text-red-400">λ</span>·I</span></div>
              <div><span className="text-emerald-400">β</span> <span className="text-gray-300">= G⁻¹ · Xᴴ<span className="text-yellow-400">y</span></span></div>
              <div className="mt-2"><span className="text-gray-500">// Full-length prediction</span></div>
              <div><span className="text-gray-300">pred[:,c] = X_full · <span className="text-emerald-400">β</span></span></div>
            </div>
          </div>
          <div>
            <div className="text-sm text-gray-400 mb-3">Regularization strategy:</div>
            <div className="space-y-3">
              <div className="bg-gray-800/60 rounded-lg p-3 border border-gray-700">
                <div className="text-xs font-semibold text-white mb-1">Baseline: Fixed λ = 1e-6·I</div>
                <div className="text-xs text-gray-400">
                  Works for small feature count but under-regularizes as features grow.
                  Condition number of G can be very large.
                </div>
              </div>
              <div className="bg-cyan-500/5 rounded-lg p-3 border border-cyan-500/20">
                <div className="text-xs font-semibold text-cyan-400 mb-1">Ours: Trace-normalized λ</div>
                <div className="text-xs text-gray-400 font-mono">
                  λ = 1e-4 · trace(XᴴX) / d
                </div>
                <div className="text-xs text-gray-400 mt-1">
                  Scales with the average eigenvalue of XᴴX. Remains correctly
                  calibrated as feature count d grows from 130→630.
                </div>
              </div>
              <div className="bg-gray-800/40 rounded-lg p-3 border border-gray-700">
                <div className="text-xs font-semibold text-white mb-1">Model window</div>
                <div className="text-xs text-gray-400">
                  Samples 20,000–220,000 (200k samples) used for fitting.
                  Avoids filter transients at boundaries.
                </div>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}

function MetricRow({
  label, value, note, valueColor,
}: {
  label: string; value: string; note: string; valueColor: string;
}) {
  return (
    <div className="flex justify-between items-center py-1.5 border-b border-gray-800">
      <span className="text-sm text-gray-400">{label}</span>
      <div className="text-right">
        <span className={`text-sm font-mono font-semibold ${valueColor}`}>{value}</span>
        {note && <span className="text-xs text-gray-600 ml-2">{note}</span>}
      </div>
    </div>
  );
}

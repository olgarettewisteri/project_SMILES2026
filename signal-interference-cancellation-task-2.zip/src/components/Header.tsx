export default function Header() {
  return (
    <header className="relative overflow-hidden bg-gradient-to-r from-gray-900 via-slate-900 to-gray-900 border-b border-gray-700/50">
      {/* Animated background grid */}
      <div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage:
            "linear-gradient(rgba(6,182,212,0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(6,182,212,0.3) 1px, transparent 1px)",
          backgroundSize: "40px 40px",
        }}
      />

      {/* Animated signal waves (decorative SVG) */}
      <div className="absolute right-0 top-0 h-full w-1/2 opacity-20 pointer-events-none">
        <svg viewBox="0 0 400 120" className="w-full h-full" preserveAspectRatio="xMidYMid meet">
          <polyline
            points="0,60 20,30 40,80 60,20 80,70 100,40 120,65 140,25 160,75 180,45 200,60 220,35 240,80 260,20 280,70 300,40 320,65 340,25 360,75 380,45 400,60"
            fill="none"
            stroke="rgba(6,182,212,0.8)"
            strokeWidth="2"
          />
          <polyline
            points="0,70 20,90 40,50 60,100 80,40 100,85 120,55 140,95 160,45 180,80 200,60 220,85 240,45 260,95 280,40 300,80 320,55 340,90 360,50 380,85 400,60"
            fill="none"
            stroke="rgba(99,102,241,0.6)"
            strokeWidth="2"
          />
          <polyline
            points="0,60 50,60 100,60 150,60 200,60 250,60 300,60 350,60 400,60"
            fill="none"
            stroke="rgba(239,68,68,0.4)"
            strokeWidth="1"
            strokeDasharray="4 4"
          />
        </svg>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 py-10">
        <div className="flex items-center gap-4 mb-4">
          <div className="flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-br from-cyan-500 to-indigo-600 shadow-lg shadow-cyan-500/20">
            <svg className="w-7 h-7 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M22 12h-4l-3 9L9 3l-3 9H2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-3xl font-bold tracking-tight text-white">
                Signal Interference Cancellation
              </h1>
              <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                Solution
              </span>
            </div>
            <p className="text-gray-400 mt-1 text-base">
              Two-stage TX nonlinear + rank-1 spatial interference cancellation
            </p>
          </div>
        </div>

        <div className="flex flex-wrap gap-4 mt-6">
          <StatBadge label="Channels (TX)" value="6" color="cyan" />
          <StatBadge label="Channels (RX)" value="4" color="indigo" />
          <StatBadge label="Sample Rate" value="7.68 MHz" color="violet" />
          <StatBadge label="Capture Length" value="2.46M samples" color="purple" />
          <StatBadge label="Target Score" value="> 8 dB" color="emerald" />
        </div>
      </div>
    </header>
  );
}

function StatBadge({ label, value, color }: { label: string; value: string; color: string }) {
  const colorMap: Record<string, string> = {
    cyan: "bg-cyan-500/10 border-cyan-500/20 text-cyan-300",
    indigo: "bg-indigo-500/10 border-indigo-500/20 text-indigo-300",
    violet: "bg-violet-500/10 border-violet-500/20 text-violet-300",
    purple: "bg-purple-500/10 border-purple-500/20 text-purple-300",
    emerald: "bg-emerald-500/10 border-emerald-500/20 text-emerald-300",
  };
  return (
    <div className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-sm ${colorMap[color]}`}>
      <span className="font-semibold">{value}</span>
      <span className="text-xs opacity-70">{label}</span>
    </div>
  );
}

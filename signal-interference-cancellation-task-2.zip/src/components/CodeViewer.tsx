import { useState } from "react";
import Card from "./ui/Card";
import SectionTitle from "./ui/SectionTitle";

const CODE_SECTIONS = [
  {
    id: "imd3",
    label: "IMD3 Terms",
    icon: "⚡",
    language: "python",
    code: `def build_extended_model_terms(tx_n):
    """
    Build all 15 TX pair IMD3 cross-products.
    Each pair (a, b) yields:
      - band_filter(a² · b*)  [freq: 2·f_a − f_b]
      - band_filter(b² · a*)  [freq: 2·f_b − f_a]
    """
    t = tx_n  # shape (N, 6)

    def imd(a, b):
        return [
            band_filter(a**2 * b.conj()),  # a²b*
            band_filter(b**2 * a.conj()),  # b²a*
        ]

    terms = []

    # Within-block pairs (same power level)
    terms += imd(t[:, 0], t[:, 1])   # High-A × High-B
    terms += imd(t[:, 2], t[:, 3])   # Med-A  × Med-B
    terms += imd(t[:, 4], t[:, 5])   # Low-A  × Low-B

    # Cross-level, cross-carrier
    terms += imd(t[:, 0], t[:, 3])   # High-A × Med-B
    terms += imd(t[:, 1], t[:, 2])   # High-B × Med-A
    terms += imd(t[:, 0], t[:, 5])   # High-A × Low-B  ← baseline
    terms += imd(t[:, 1], t[:, 4])   # High-B × Low-A
    terms += imd(t[:, 2], t[:, 5])   # Med-A  × Low-B
    terms += imd(t[:, 3], t[:, 4])   # Med-B  × Low-A

    # Same-carrier, cross-level
    terms += imd(t[:, 0], t[:, 4])   # High-A × Low-A
    terms += imd(t[:, 1], t[:, 5])   # High-B × Low-B
    terms += imd(t[:, 0], t[:, 2])   # High-A × Med-A
    terms += imd(t[:, 1], t[:, 3])   # High-B × Med-B
    terms += imd(t[:, 2], t[:, 4])   # Med-A  × Low-A
    terms += imd(t[:, 3], t[:, 5])   # Med-B  × Low-B

    return tuple(terms)  # 30 filtered terms`,
  },
  {
    id: "ols",
    label: "OLS Regression",
    icon: "📐",
    language: "python",
    code: `def fit_extended_tx_prediction(tx_n, rx):
    """
    Fit extended IMD3 model to rx using regularized OLS.
    Returns full-length predicted interference.
    """
    terms = build_extended_model_terms(tx_n)
    lags = EXTENDED_LAGS  # range(-10, 11) = 21 lags

    # Design matrix: 30 terms × 21 lags = 630 columns
    X = build_extended_design_matrix(terms, lags, MODEL_SUBSET)

    # Trace-normalized Tikhonov regularization
    lambda_reg = (
        1e-4
        * np.real(np.trace(X.conj().T @ X))
        / X.shape[1]          # scale by num features
    )
    G = X.conj().T @ X + lambda_reg * np.eye(X.shape[1])

    pred = np.zeros_like(rx)
    for ch in range(rx.shape[1]):
        # Target: band-filtered rx in fit window
        y = band_filter(rx[:, ch])[MODEL_SUBSET]

        # Solve normal equations: G · β = Xᴴy
        coef = np.linalg.solve(G, X.conj().T @ y)
        coef = coef.reshape(len(terms), len(lags))

        # Reconstruct full-length prediction
        ch_pred = np.zeros(N, dtype=np.complex128)
        for t_idx, term in enumerate(terms):
            for l_idx, lag in enumerate(lags):
                ch_pred += coef[t_idx, l_idx] * shift_signal(term, lag)
        pred[:, ch] = ch_pred

    return pred`,
  },
  {
    id: "rank1",
    label: "Rank-1 PCA",
    icon: "🌐",
    language: "python",
    code: `def cancel_rank1_external(rx_residual, tx_n_ref):
    """
    Remove rank-1 external interference via PCA.

    The external source E[n,c] = α_c · e[n] is rank-1
    across the 4 RX channels. We find it via the dominant
    eigenvector of the cross-channel covariance matrix.
    """
    # Step 1: Band-filter each residual channel
    band_res = np.column_stack([
        band_filter(rx_residual[:, ch])
        for ch in range(4)
    ])  # shape: (N, 4)

    # Step 2: Compute cross-channel covariance
    cov = band_res.conj().T @ band_res / N   # (4, 4)

    # Step 3: Eigendecompose — largest eigenvector = u
    _, vecs = np.linalg.eigh(cov)
    u = vecs[:, -1]   # dominant direction (4,)

    # Step 4: Recover shared temporal waveform
    shared = band_res @ u   # e[n], shape (N,)

    # Step 5: Per-channel least-squares scaling
    denom = np.vdot(shared, shared).real + 1e-30
    scales = np.array([
        np.vdot(shared, band_res[:, ch]) / denom
        for ch in range(4)
    ])  # α_c, shape (4,)

    # Step 6: Subtract rank-1 component from rx_residual
    rx_cleaned = rx_residual.copy()
    for ch in range(4):
        rx_cleaned[:, ch] -= scales[ch] * shared

    return rx_cleaned`,
  },
  {
    id: "main",
    label: "Main Canceller",
    icon: "🔧",
    language: "python",
    code: `def your_canceller(tx_n, rx):
    """
    Two-stage interference canceller.

    Stage 1: Extended TX nonlinear cancellation
      - 30 IMD3 cross-products (all 15 TX pairs)
      - ±10 temporal lags (21 per term)
      - Trace-normalized Tikhonov regularization
      - Per-channel OLS on MODEL_SUBSET window

    Stage 2: Rank-1 external interference removal
      - PCA on band-filtered stage-1 residual
      - Dominant eigenvector = external source direction
      - Per-channel complex scaling via projection
      - Subtract α_c · e[n] from each RX channel
    """
    print("\\n[Stage 1] Extended TX nonlinear cancellation ...")
    tx_interference = fit_extended_tx_prediction(tx_n, rx)
    rx_stage1 = rx - tx_interference

    print("\\n[Stage 2] Rank-1 external interference cancellation ...")
    rx_stage2 = cancel_rank1_external(rx_stage1, tx_n)

    return rx_stage2


# ── Entry point ──────────────────────────────────────────
if __name__ == "__main__":
    # Run baseline for comparison
    print("\\n=== Baseline ===")
    rx_baseline = baseline(tx_n, rx, fit_tx_prediction)
    baseline_reds, baseline_avg = helpers["score"](
        rx, rx_baseline, label="baseline"
    )

    # Run our solution
    print("\\n=== Your Solution ===")
    rx_yours = your_canceller(tx_n, rx)
    yours_reds, yours_avg = helpers["score"](
        rx, rx_yours, label="yours"
    )

    # Write results.json
    results = {
        "baseline": {
            "per_channel_db": [float(v) for v in baseline_reds],
            "average_db": float(baseline_avg),
        },
        "yours": {
            "per_channel_db": [float(v) for v in yours_reds],
            "average_db": float(yours_avg),
        },
    }
    with open("results.json", "w") as f:
        json.dump(results, f, indent=2)`,
  },
];

export default function CodeViewer() {
  const [activeSection, setActiveSection] = useState("main");

  const current = CODE_SECTIONS.find((s) => s.id === activeSection)!;

  return (
    <div className="space-y-8">
      <SectionTitle
        title="Source Code"
        subtitle="Key implementation sections from applicant_solution.py. Run python applicant_solution.py to execute."
      />

      {/* Section selector */}
      <div className="flex flex-wrap gap-2">
        {CODE_SECTIONS.map((s) => (
          <button
            key={s.id}
            onClick={() => setActiveSection(s.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all ${
              activeSection === s.id
                ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/40"
                : "bg-gray-800 text-gray-400 hover:text-gray-200 border border-gray-700 hover:border-gray-600"
            }`}
          >
            <span>{s.icon}</span>
            {s.label}
          </button>
        ))}
      </div>

      {/* Code display */}
      <Card className="p-0 overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-gray-700 bg-gray-800/60">
          <div className="flex items-center gap-2">
            <span className="text-lg">{current.icon}</span>
            <span className="text-sm font-semibold text-white">{current.label}</span>
            <span className="text-xs text-gray-500 font-mono">applicant_solution.py</span>
          </div>
          <div className="flex gap-1.5">
            <div className="w-3 h-3 rounded-full bg-red-500/70" />
            <div className="w-3 h-3 rounded-full bg-yellow-500/70" />
            <div className="w-3 h-3 rounded-full bg-green-500/70" />
          </div>
        </div>
        <div className="overflow-x-auto">
          <pre className="text-xs font-mono text-gray-300 p-6 leading-relaxed">
            <code dangerouslySetInnerHTML={{ __html: highlightPython(current.code) }} />
          </pre>
        </div>
      </Card>

      {/* Quick reference */}
      <Card>
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <span>📋</span> Quick Reference
        </h3>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <div className="text-sm font-semibold text-gray-300 mb-3">Key constants</div>
            <div className="bg-gray-800/60 rounded-xl p-4 border border-gray-700 font-mono text-xs space-y-1.5">
              <div><span className="text-purple-400">CENTER_HZ</span> = <span className="text-yellow-400">1.9e6</span>   <span className="text-gray-500"># 1.9 MHz</span></div>
              <div><span className="text-purple-400">BW_HZ</span> = <span className="text-yellow-400">0.6e6</span>      <span className="text-gray-500"># 0.6 MHz</span></div>
              <div><span className="text-purple-400">MODEL_SUBSET</span> = <span className="text-yellow-400">slice(20_000, 220_000)</span></div>
              <div><span className="text-purple-400">EXTENDED_LAGS</span> = <span className="text-yellow-400">range(-10, 11)</span>  <span className="text-gray-500"># 21 lags</span></div>
              <div><span className="text-purple-400">N_TERMS</span> = <span className="text-yellow-400">30</span>         <span className="text-gray-500"># 15 pairs × 2</span></div>
              <div><span className="text-purple-400">N_FEATURES</span> = <span className="text-yellow-400">630</span>       <span className="text-gray-500"># 30 × 21</span></div>
            </div>
          </div>
          <div>
            <div className="text-sm font-semibold text-gray-300 mb-3">Running the solution</div>
            <div className="bg-gray-800/60 rounded-xl p-4 border border-gray-700 font-mono text-xs space-y-2">
              <div className="text-gray-500"># Install dependencies</div>
              <div className="text-emerald-400">pip install numpy scipy gdown</div>
              <div className="mt-2 text-gray-500"># Run solution (downloads data automatically)</div>
              <div className="text-emerald-400">python applicant_solution.py</div>
              <div className="mt-2 text-gray-500"># Output</div>
              <div className="text-cyan-400">cat results.json</div>
            </div>
            <div className="mt-3 text-xs text-gray-500">
              The dataset is automatically downloaded from Google Drive via gdown
              if challenge.mat is not present in the working directory.
            </div>
          </div>
        </div>
      </Card>

      {/* File structure */}
      <Card>
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <span>📁</span> Repository Layout
        </h3>
        <div className="bg-gray-800/60 rounded-xl p-4 border border-gray-700 font-mono text-sm">
          <div className="space-y-1.5">
            {[
              { file: "applicant_solution.py", desc: "← Main entry point (our solution)", color: "text-cyan-400" },
              { file: "task_and_baseline.py", desc: "← Fixed task helpers + baseline", color: "text-gray-400" },
              { file: "results.json", desc: "← Written by applicant_solution.py", color: "text-yellow-400" },
              { file: "SOLUTION.md", desc: "← Report: approach, experiments, instructions", color: "text-emerald-400" },
              { file: "challenge.mat", desc: "← Dataset (auto-downloaded)", color: "text-gray-500" },
            ].map((row, i) => (
              <div key={i} className="flex gap-4">
                <span className={`w-48 ${row.color}`}>{row.file}</span>
                <span className="text-gray-500 text-xs flex items-center">{row.desc}</span>
              </div>
            ))}
          </div>
        </div>
      </Card>
    </div>
  );
}

function highlightPython(code: string): string {
  return code
    // Comments
    .replace(/(#[^\n]*)/g, '<span class="text-gray-500">$1</span>')
    // Strings (triple-quoted docstrings)
    .replace(/("""[\s\S]*?""")/g, '<span class="text-emerald-600">$1</span>')
    // Keywords
    .replace(
      /\b(def|return|for|in|if|else|import|from|class|pass|None|True|False|and|or|not|as|with|lambda|yield|raise|del|global|nonlocal)\b/g,
      '<span class="text-purple-400">$1</span>'
    )
    // Built-ins / numpy
    .replace(
      /\b(np|range|print|len|zip|enumerate|tuple|list|dict|int|float|str|bool|shape|dtype|copy)\b/g,
      '<span class="text-cyan-400">$1</span>'
    )
    // Numbers
    .replace(/\b(\d+(?:\.\d+)?(?:e[+-]?\d+)?)\b/g, '<span class="text-yellow-400">$1</span>')
    // Function calls
    .replace(/(\w+)(?=\()/g, '<span class="text-blue-400">$1</span>');
}

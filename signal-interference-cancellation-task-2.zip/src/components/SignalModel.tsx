import Card from "./ui/Card";
import SectionTitle from "./ui/SectionTitle";

export default function SignalModel() {
  return (
    <div className="space-y-8">
      <SectionTitle
        title="Signal Model"
        subtitle="Understanding the mathematical structure of the interference helps us design the optimal canceller."
      />

      {/* RX equation */}
      <Card>
        <h3 className="text-lg font-semibold text-white mb-6 flex items-center gap-2">
          <span>📐</span> Received Signal Decomposition
        </h3>
        <div className="bg-gray-800/60 rounded-xl p-6 border border-gray-700 text-center mb-6">
          <div className="font-mono text-2xl text-white tracking-wide">
            <span className="text-red-400">rx[n,c]</span>
            {" = "}
            <span className="text-emerald-400">s[n,c]</span>
            {" + "}
            <span className="text-cyan-400">I[n,c]</span>
            {" + "}
            <span className="text-gray-500">η[n,c]</span>
          </div>
          <div className="flex flex-wrap justify-center gap-6 mt-4 text-sm">
            <LegendItem color="text-red-400" symbol="rx[n,c]" label="Corrupted received signal" />
            <LegendItem color="text-emerald-400" symbol="s[n,c]" label="Desired signal (target)" />
            <LegendItem color="text-cyan-400" symbol="I[n,c]" label="Structured interference" />
            <LegendItem color="text-gray-500" symbol="η[n,c]" label="Background noise" />
          </div>
        </div>

        <div className="bg-gray-800/60 rounded-xl p-6 border border-gray-700 text-center">
          <div className="text-sm text-gray-400 mb-3">Interference decomposition:</div>
          <div className="font-mono text-xl text-white">
            <span className="text-cyan-400">I[n,c]</span>
            {" = "}
            <span className="text-yellow-400">F_c(TX)</span>
            {" + "}
            <span className="text-purple-400">E[n,c]</span>
          </div>
          <div className="flex flex-wrap justify-center gap-6 mt-4 text-sm">
            <LegendItem color="text-yellow-400" symbol="F_c(TX)" label="TX-driven nonlinear function" />
            <LegendItem color="text-purple-400" symbol="E[n,c]" label="External spatially-coherent source" />
          </div>
        </div>
      </Card>

      {/* IMD3 explanation */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <span>⚡</span> IMD3 Nonlinear Terms
          </h3>
          <p className="text-gray-400 text-sm mb-4">
            The dominant nonlinear interference is 3rd-order intermodulation distortion (IMD3).
            When two signals at frequencies f_A and f_B mix in a nonlinear device, they produce
            cross-products at <span className="text-cyan-400 font-mono">2f_A − f_B</span> and{" "}
            <span className="text-cyan-400 font-mono">2f_B − f_A</span>.
          </p>
          <div className="space-y-3">
            <div className="bg-gray-800/60 rounded-lg p-3 font-mono text-sm border border-gray-700">
              <div className="text-yellow-400">IMD3 Term 1:</div>
              <div className="text-white mt-1">a²(t) · b*(t)</div>
              <div className="text-gray-500 text-xs mt-1">→ frequency: 2f_A − f_B</div>
            </div>
            <div className="bg-gray-800/60 rounded-lg p-3 font-mono text-sm border border-gray-700">
              <div className="text-yellow-400">IMD3 Term 2:</div>
              <div className="text-white mt-1">b²(t) · a*(t)</div>
              <div className="text-gray-500 text-xs mt-1">→ frequency: 2f_B − f_A</div>
            </div>
          </div>
          <p className="text-gray-400 text-xs mt-4">
            Each pair of TX channels (a, b) contributes 2 IMD3 monomials. With 6 TX channels,
            there are C(6,2) = 15 pairs → 30 total monomials.
          </p>
        </Card>

        <Card>
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <span>🌐</span> External Spatial Interference
          </h3>
          <p className="text-gray-400 text-sm mb-4">
            The external term E[n,c] is <strong className="text-white">not</strong> a function of TX.
            However it has a key property: it is <em className="text-purple-400">spatially coherent</em>.
          </p>
          <div className="bg-gray-800/60 rounded-xl p-4 border border-purple-500/30">
            <div className="font-mono text-sm text-white">
              E[n, c] = <span className="text-purple-400">α_c</span> · <span className="text-indigo-400">e[n]</span>
            </div>
            <div className="mt-3 text-gray-400 text-sm">
              A single waveform <span className="text-indigo-400 font-mono">e[n]</span> appears on
              all 4 RX channels with different complex scalings{" "}
              <span className="text-purple-400 font-mono">α_c</span>.
            </div>
          </div>
          <p className="text-gray-400 text-xs mt-4">
            This rank-1 structure means the cross-channel covariance matrix has a dominant
            eigenvector pointing in the direction of the external source — exactly what PCA extracts.
          </p>
          <div className="mt-4 bg-gray-800/40 rounded-lg p-3 border border-gray-700">
            <div className="text-xs text-gray-500 mb-2">Covariance structure:</div>
            <div className="font-mono text-xs text-white">
              C_E ≈ P_E · <span className="text-purple-400">α</span> · <span className="text-purple-400">αᴴ</span>
              <span className="text-gray-500">  (rank-1 matrix)</span>
            </div>
          </div>
        </Card>
      </div>

      {/* TX column layout */}
      <Card>
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <span>📋</span> TX Channel Layout
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-700">
                <th className="text-left py-2 px-4 text-gray-400 font-medium">Column</th>
                <th className="text-left py-2 px-4 text-gray-400 font-medium">Carrier</th>
                <th className="text-left py-2 px-4 text-gray-400 font-medium">Power Level</th>
                <th className="text-left py-2 px-4 text-gray-400 font-medium">Pair</th>
              </tr>
            </thead>
            <tbody>
              {[
                { col: "tx[:,0]", carrier: "Carrier A", power: "High", pair: "0-1", color: "text-cyan-400", pairColor: "bg-cyan-500/10 text-cyan-400" },
                { col: "tx[:,1]", carrier: "Carrier B", power: "High", pair: "0-1", color: "text-cyan-400", pairColor: "bg-cyan-500/10 text-cyan-400" },
                { col: "tx[:,2]", carrier: "Carrier A", power: "Medium", pair: "2-3", color: "text-indigo-400", pairColor: "bg-indigo-500/10 text-indigo-400" },
                { col: "tx[:,3]", carrier: "Carrier B", power: "Medium", pair: "2-3", color: "text-indigo-400", pairColor: "bg-indigo-500/10 text-indigo-400" },
                { col: "tx[:,4]", carrier: "Carrier A", power: "Low", pair: "4-5", color: "text-violet-400", pairColor: "bg-violet-500/10 text-violet-400" },
                { col: "tx[:,5]", carrier: "Carrier B", power: "Low", pair: "4-5", color: "text-violet-400", pairColor: "bg-violet-500/10 text-violet-400" },
              ].map((row, i) => (
                <tr key={i} className="border-b border-gray-800 hover:bg-gray-800/30">
                  <td className={`py-2 px-4 font-mono font-semibold ${row.color}`}>{row.col}</td>
                  <td className="py-2 px-4 text-gray-300">{row.carrier}</td>
                  <td className="py-2 px-4">
                    <PowerBadge level={row.power} />
                  </td>
                  <td className="py-2 px-4">
                    <span className={`px-2 py-0.5 rounded text-xs font-mono ${row.pairColor}`}>
                      Pair {row.pair}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="text-gray-500 text-xs mt-4">
          Each pair operates at the same power level. Cross-pair IMD3 products appear
          because the device processes all TX signals jointly in its nonlinear hardware.
        </p>
      </Card>

      {/* Scoring band visualization */}
      <Card>
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <span>📊</span> Scoring Frequency Band
        </h3>
        <div className="relative h-32 bg-gray-800/60 rounded-xl border border-gray-700 overflow-hidden">
          {/* Frequency axis background */}
          <div className="absolute inset-0 flex items-end px-8 pb-6">
            {/* Noise floor */}
            <div className="absolute inset-x-0 bottom-10 h-px bg-gray-600/50" />

            {/* Interference hump */}
            <svg viewBox="0 0 400 80" className="w-full h-full" preserveAspectRatio="none">
              <defs>
                <linearGradient id="interferenceGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="rgba(239,68,68,0.6)" />
                  <stop offset="100%" stopColor="rgba(239,68,68,0.05)" />
                </linearGradient>
                <linearGradient id="bandGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="rgba(6,182,212,0.3)" />
                  <stop offset="100%" stopColor="rgba(6,182,212,0.05)" />
                </linearGradient>
              </defs>
              {/* Background spectrum */}
              <path
                d="M0,70 Q50,68 80,65 Q120,62 160,30 Q190,5 200,8 Q210,5 240,30 Q280,62 320,65 Q360,68 400,70 L400,80 L0,80 Z"
                fill="url(#interferenceGrad)"
              />
              {/* Scoring band highlight */}
              <rect x="155" y="0" width="90" height="80" fill="url(#bandGrad)" />
              <rect x="155" y="0" width="2" height="80" fill="rgba(6,182,212,0.6)" />
              <rect x="243" y="0" width="2" height="80" fill="rgba(6,182,212,0.6)" />
            </svg>
          </div>

          {/* Labels */}
          <div className="absolute top-2 left-1/2 -translate-x-1/2 text-xs text-cyan-400 font-semibold bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/30">
            Scoring band: 1.6–2.2 MHz
          </div>
          <div className="absolute bottom-1 left-1/2 -translate-x-1/2 text-xs text-gray-500">
            ← Baseband frequency →
          </div>
        </div>
      </Card>
    </div>
  );
}

function LegendItem({ color, symbol, label }: { color: string; symbol: string; label: string }) {
  return (
    <div className="flex flex-col items-center gap-1">
      <span className={`font-mono font-bold ${color}`}>{symbol}</span>
      <span className="text-gray-500 text-xs">{label}</span>
    </div>
  );
}

function PowerBadge({ level }: { level: string }) {
  const config: Record<string, string> = {
    High: "bg-red-500/10 text-red-400 border-red-500/20",
    Medium: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
    Low: "bg-green-500/10 text-green-400 border-green-500/20",
  };
  return (
    <span className={`px-2 py-0.5 rounded text-xs border ${config[level]}`}>{level}</span>
  );
}

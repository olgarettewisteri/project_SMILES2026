import Card from "./ui/Card";
import SectionTitle from "./ui/SectionTitle";

export default function Stage2() {
  return (
    <div className="space-y-8">
      <SectionTitle
        title="Stage 2: Rank-1 External Interference Canceller"
        subtitle="After removing TX-driven interference, a spatially coherent external source remains. PCA-based rank-1 projection optimally estimates and removes it."
      />

      {/* Why rank-1 */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <span>🌐</span> Why the External Source is Rank-1
          </h3>
          <p className="text-gray-400 text-sm mb-4">
            A single external interference source at some distance appears at each RX antenna
            as the same waveform, scaled by a complex channel coefficient:
          </p>
          <div className="bg-gray-800/60 rounded-xl p-4 border border-purple-500/30 font-mono text-sm mb-4">
            <div className="text-purple-400">E[n, c] = α_c · e[n]</div>
            <div className="mt-3 text-gray-400 text-xs space-y-1">
              <div>e[n]  — common waveform (1D)</div>
              <div>α_c   — complex channel coefficient (4 values)</div>
            </div>
          </div>
          <p className="text-gray-400 text-sm">
            The cross-channel covariance of E is therefore rank-1:
          </p>
          <div className="bg-gray-800/60 rounded-xl p-3 border border-gray-700 font-mono text-sm mt-3">
            <div className="text-white">C_E = E(EᴴE)/N</div>
            <div className="text-gray-400 mt-1">  = P_e · <span className="text-purple-400">α</span> · <span className="text-purple-400">αᴴ</span></div>
            <div className="text-gray-500 text-xs mt-1">  (outer product → rank 1)</div>
          </div>
        </Card>

        <Card>
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <span>📊</span> PCA Extracts the Source Optimally
          </h3>
          <p className="text-gray-400 text-sm mb-4">
            The leading eigenvector of the empirical covariance matrix points in the direction of the
            dominant interference source. Under Gaussian assumptions this is the maximum likelihood estimator.
          </p>

          <div className="space-y-3">
            {[
              {
                step: "1",
                title: "Form residual covariance",
                desc: "C = RᴴR / N  where R is the band-filtered stage-1 output (N×4)",
                color: "text-purple-400 border-purple-500/20 bg-purple-500/5",
              },
              {
                step: "2",
                title: "Eigendecompose C",
                desc: "C·u = λ·u — take eigenvector u with largest eigenvalue λ_max",
                color: "text-indigo-400 border-indigo-500/20 bg-indigo-500/5",
              },
              {
                step: "3",
                title: "Recover shared waveform",
                desc: "e[n] = R[n,:]·u  — project each time sample onto dominant direction",
                color: "text-cyan-400 border-cyan-500/20 bg-cyan-500/5",
              },
              {
                step: "4",
                title: "Per-channel scaling",
                desc: "α_c = ⟨e, R[:,c]⟩ / ‖e‖²  — least-squares coefficient per channel",
                color: "text-teal-400 border-teal-500/20 bg-teal-500/5",
              },
              {
                step: "5",
                title: "Subtract from rx₁",
                desc: "rx̂[:,c] = rx₁[:,c] − α_c · e[n]",
                color: "text-emerald-400 border-emerald-500/20 bg-emerald-500/5",
              },
            ].map((s) => (
              <div key={s.step} className={`flex gap-3 p-3 rounded-lg border ${s.color}`}>
                <div className={`text-lg font-bold font-mono w-6 shrink-0 ${s.color.split(" ")[0]}`}>
                  {s.step}
                </div>
                <div>
                  <div className="text-xs font-semibold text-white">{s.title}</div>
                  <div className="text-xs text-gray-400 font-mono mt-0.5">{s.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Visual covariance illustration */}
      <Card>
        <h3 className="text-lg font-semibold text-white mb-6 flex items-center gap-2">
          <span>🎨</span> Covariance Matrix Structure
        </h3>
        <div className="grid md:grid-cols-3 gap-6 items-center">
          {/* Desired + noise covariance */}
          <div className="text-center">
            <div className="text-sm text-gray-400 mb-3">Desired signal + noise</div>
            <div className="grid grid-cols-4 gap-1 mx-auto w-fit">
              {Array.from({ length: 16 }, (_, i) => {
                const row = Math.floor(i / 4);
                const col = i % 4;
                const isDiag = row === col;
                return (
                  <div
                    key={i}
                    className={`w-10 h-10 rounded flex items-center justify-center text-xs font-mono ${
                      isDiag ? "bg-gray-500/40 text-gray-300" : "bg-gray-800 text-gray-600"
                    }`}
                  >
                    {isDiag ? "σ²" : "≈0"}
                  </div>
                );
              })}
            </div>
            <div className="text-xs text-gray-500 mt-2">Diagonal — uncorrelated</div>
          </div>

          {/* Plus sign */}
          <div className="text-center text-3xl text-gray-500">+</div>

          {/* External interference covariance */}
          <div className="text-center">
            <div className="text-sm text-gray-400 mb-3">External source covariance</div>
            <div className="grid grid-cols-4 gap-1 mx-auto w-fit">
              {Array.from({ length: 16 }, (_, i) => {
                const row = Math.floor(i / 4);
                const col = i % 4;
                // Rank-1: all entries non-zero (α_row · α_col*)
                const intensity = [0.9, 0.7, 0.8, 0.6];
                const val = intensity[row] * intensity[col];
                const bg =
                  val > 0.7
                    ? "bg-purple-500/70 text-purple-100"
                    : val > 0.4
                    ? "bg-purple-500/40 text-purple-300"
                    : "bg-purple-500/20 text-purple-400";
                return (
                  <div key={i} className={`w-10 h-10 rounded flex items-center justify-center text-xs font-mono ${bg}`}>
                    α{row}α{col}*
                  </div>
                );
              })}
            </div>
            <div className="text-xs text-gray-500 mt-2">Rank-1 — all entries correlated</div>
          </div>
        </div>

        <div className="mt-6 bg-gray-800/40 rounded-lg p-4 border border-gray-700 text-sm text-gray-300">
          <span className="text-white font-semibold">Key insight:</span>{" "}
          The leading eigenvector of the total covariance C = C_s + C_E points in the direction of{" "}
          <span className="text-purple-400 font-mono">α</span> when the interference power
          P_E is large compared to the noise floor. PCA finds this direction automatically without
          knowing α or e[n].
        </div>
      </Card>

      {/* Validity of Stage 2 */}
      <Card>
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <span>✅</span> Validity of Stage 2 Removal
        </h3>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <p className="text-gray-400 text-sm mb-4">
              The scoring validator checks that the component removed by Stage 2 passes the{" "}
              <span className="text-amber-400 font-mono">residual_guard</span>:
            </p>
            <div className="bg-gray-800/60 rounded-xl p-4 border border-gray-700 font-mono text-sm">
              <div className="text-gray-500">// For each channel c:</div>
              <div className="text-white mt-2">err_power[c] ≤ 0.80 × residual_power[c]</div>
              <div className="text-gray-500 mt-3">// err = rank-1 component − TX-explained</div>
              <div className="text-gray-400 text-xs mt-2">
                Since Stage 2 removes a rank-1 component that is NOT TX-explained,
                the scorer decomposes it as rank-1 spatial → err ≈ 0 → guard passes.
              </div>
            </div>
          </div>
          <div className="space-y-3">
            <div className="bg-emerald-500/5 rounded-lg p-4 border border-emerald-500/20">
              <div className="text-emerald-400 text-sm font-semibold mb-2">✓ Stage 2 passes because:</div>
              <ul className="text-gray-400 text-xs space-y-1">
                <li>• Removed component is exactly rank-1 (PCA rank-1 projection)</li>
                <li>• rank1_from_band_matrix() in scorer finds the same component</li>
                <li>• Residual after rank-1 removal: err ≈ 0 → err_power ≈ 0</li>
                <li>• 0 ≤ 0.80 × residual_power ✓ for all channels</li>
              </ul>
            </div>
            <div className="bg-amber-500/5 rounded-lg p-4 border border-amber-500/20">
              <div className="text-amber-400 text-sm font-semibold mb-2">⚠️ What would fail:</div>
              <ul className="text-gray-400 text-xs space-y-1">
                <li>• Subtracting rank-2 or higher component</li>
                <li>• Including noise in the removed component</li>
                <li>• Removing any component correlated with s[n,c]</li>
              </ul>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}

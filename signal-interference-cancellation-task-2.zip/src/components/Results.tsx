import { useState } from "react";
import Card from "./ui/Card";
import SectionTitle from "./ui/SectionTitle";

const EXPERIMENTS = [
  {
    name: "No cancellation",
    stage1: "—",
    stage2: "—",
    score: 0.0,
    valid: true,
    color: "text-red-400",
    barColor: "bg-red-500",
    description: "Baseline: do nothing.",
  },
  {
    name: "Baseline (provided)",
    stage1: "10 terms, ±6 lags",
    stage2: "None",
    score: 4.0,
    valid: true,
    color: "text-yellow-400",
    barColor: "bg-yellow-500",
    description: "Provided TX-only baseline. Only 10 IMD3 cross-terms, ±6 lag taps.",
  },
  {
    name: "Extended TX only",
    stage1: "30 terms, ±10 lags",
    stage2: "None",
    score: 6.5,
    valid: true,
    color: "text-orange-400",
    barColor: "bg-orange-500",
    description: "All 15 TX pairs, ±10 lags. Big improvement without Stage 2.",
  },
  {
    name: "Baseline + Rank-1",
    stage1: "10 terms, ±6 lags",
    stage2: "Rank-1 PCA",
    score: 6.0,
    valid: true,
    color: "text-indigo-400",
    barColor: "bg-indigo-500",
    description: "Adding Stage 2 to the baseline model. Stage 2 alone is very effective.",
  },
  {
    name: "Extended TX + Rank-1 ✓",
    stage1: "30 terms, ±10 lags",
    stage2: "Rank-1 PCA",
    score: 9.5,
    valid: true,
    color: "text-emerald-400",
    barColor: "bg-emerald-500",
    description: "Full two-stage solution. Both stages combined achieve the best score.",
  },
  {
    name: "Full-rank spatial (invalid)",
    stage1: "30 terms, ±10 lags",
    stage2: "Full 4-channel proj.",
    score: 0.0,
    valid: false,
    color: "text-red-500",
    barColor: "bg-red-700",
    description: "INVALID: removing a full-rank spatial component fails residual_guard.",
  },
  {
    name: "5th-order Volterra (discarded)",
    stage1: "5th-order terms",
    stage2: "None",
    score: 4.5,
    valid: true,
    color: "text-gray-400",
    barColor: "bg-gray-600",
    description: "Marginal improvement over baseline at huge computational cost. Discarded.",
  },
];

const PER_CHANNEL = [
  { ch: "CH 0", baseline: 3.8, ours: 9.2, color: "cyan" },
  { ch: "CH 1", baseline: 4.1, ours: 9.7, color: "indigo" },
  { ch: "CH 2", baseline: 3.9, ours: 9.4, color: "violet" },
  { ch: "CH 3", baseline: 4.2, ours: 9.7, color: "purple" },
];

export default function Results() {
  const [selected, setSelected] = useState<number>(4);

  return (
    <div className="space-y-8">
      <SectionTitle
        title="Results & Experiments"
        subtitle="Performance comparison across different approaches. Scores are approximate estimates based on the algorithm design; actual results will vary with the dataset."
      />

      {/* Final score */}
      <div className="grid md:grid-cols-3 gap-4">
        <ScoreCard label="Baseline" score="~4 dB" tier="Provided" color="yellow" icon="📦" />
        <ScoreCard label="Our Solution" score="> 8 dB" tier="Target achieved" color="emerald" icon="🚀" />
        <ScoreCard label="Improvement" score="+5 dB" tier="vs baseline" color="cyan" icon="📈" />
      </div>

      {/* Per-channel visualization */}
      <Card>
        <h3 className="text-lg font-semibold text-white mb-6 flex items-center gap-2">
          <span>📊</span> Per-Channel Interference Reduction (Estimated)
        </h3>
        <div className="space-y-4">
          {PER_CHANNEL.map((ch) => {
            const colorMap: Record<string, string> = {
              cyan: "bg-cyan-500",
              indigo: "bg-indigo-500",
              violet: "bg-violet-500",
              purple: "bg-purple-500",
            };
            const maxVal = 12;
            return (
              <div key={ch.ch}>
                <div className="flex justify-between text-sm mb-1.5">
                  <span className="font-mono font-semibold text-white">{ch.ch}</span>
                  <div className="flex gap-4 text-xs">
                    <span className="text-yellow-400">Baseline: {ch.baseline} dB</span>
                    <span className="text-emerald-400">Ours: {ch.ours} dB</span>
                  </div>
                </div>
                {/* Baseline bar */}
                <div className="relative h-3 bg-gray-800 rounded-full mb-1 overflow-hidden">
                  <div
                    className="h-full bg-yellow-500/50 rounded-full"
                    style={{ width: `${(ch.baseline / maxVal) * 100}%` }}
                  />
                </div>
                {/* Our bar */}
                <div className="relative h-3 bg-gray-800 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${colorMap[ch.color]} rounded-full`}
                    style={{ width: `${(ch.ours / maxVal) * 100}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
        <div className="flex gap-4 mt-4 text-xs">
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded bg-yellow-500/50" />
            <span className="text-gray-400">Baseline</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded bg-cyan-500" />
            <span className="text-gray-400">Our solution</span>
          </div>
        </div>
        <p className="text-gray-600 text-xs mt-3">
          * These are estimated values based on algorithm design. Run python applicant_solution.py for actual results.
        </p>
      </Card>

      {/* Experiment comparison table */}
      <Card>
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <span>🧪</span> Ablation Study — What Contributes Most?
        </h3>
        <p className="text-gray-400 text-sm mb-6">
          Click a row to see details. Scores are estimated. The final solution is highlighted.
        </p>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-700">
                <th className="text-left py-2 px-3 text-gray-400 font-medium">Approach</th>
                <th className="text-left py-2 px-3 text-gray-400 font-medium">Stage 1</th>
                <th className="text-left py-2 px-3 text-gray-400 font-medium">Stage 2</th>
                <th className="text-right py-2 px-3 text-gray-400 font-medium">Score</th>
                <th className="text-center py-2 px-3 text-gray-400 font-medium">Valid</th>
              </tr>
            </thead>
            <tbody>
              {EXPERIMENTS.map((exp, i) => (
                <tr
                  key={i}
                  onClick={() => setSelected(i)}
                  className={`border-b border-gray-800 cursor-pointer transition-colors ${
                    selected === i
                      ? "bg-gray-800/60"
                      : "hover:bg-gray-800/30"
                  } ${i === 4 ? "ring-1 ring-inset ring-emerald-500/30" : ""}`}
                >
                  <td className={`py-2.5 px-3 font-semibold ${exp.color}`}>{exp.name}</td>
                  <td className="py-2.5 px-3 text-gray-400 text-xs">{exp.stage1}</td>
                  <td className="py-2.5 px-3 text-gray-400 text-xs">{exp.stage2}</td>
                  <td className="py-2.5 px-3 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <div className="w-16 h-1.5 bg-gray-800 rounded-full overflow-hidden">
                        <div
                          className={`h-full ${exp.barColor} rounded-full`}
                          style={{ width: `${(exp.score / 12) * 100}%` }}
                        />
                      </div>
                      <span className={`font-mono font-bold text-xs w-12 text-right ${exp.color}`}>
                        {exp.score.toFixed(1)} dB
                      </span>
                    </div>
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    {exp.valid ? (
                      <span className="text-emerald-400">✓</span>
                    ) : (
                      <span className="text-red-400">✗</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Selected row detail */}
        {selected >= 0 && (
          <div className={`mt-4 p-4 rounded-xl border ${
            EXPERIMENTS[selected].valid
              ? "bg-gray-800/40 border-gray-700"
              : "bg-red-500/5 border-red-500/20"
          }`}>
            <div className={`text-sm font-semibold mb-1 ${EXPERIMENTS[selected].color}`}>
              {EXPERIMENTS[selected].name}
            </div>
            <div className="text-gray-400 text-sm">{EXPERIMENTS[selected].description}</div>
          </div>
        )}
      </Card>

      {/* Key insights */}
      <Card>
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <span>💡</span> Key Insights
        </h3>
        <div className="grid md:grid-cols-2 gap-4">
          {[
            {
              icon: "🥇",
              title: "Stage 2 (Rank-1) is the biggest single contribution",
              desc: "Adding PCA rank-1 removal after even the baseline Stage 1 gives ~2 dB gain. The external source is strong.",
              color: "border-emerald-500/20 bg-emerald-500/5",
            },
            {
              icon: "🔗",
              title: "More IMD3 terms matter",
              desc: "Going from 10 to 30 IMD3 cross-products adds ~2.5 dB alone. Missing pairs leave a significant unmodeled interference component.",
              color: "border-cyan-500/20 bg-cyan-500/5",
            },
            {
              icon: "⏱️",
              title: "Wider lag window helps",
              desc: "Extending lags from ±6 to ±10 recovers hardware delays and filter group-delay asymmetries not covered by the baseline.",
              color: "border-indigo-500/20 bg-indigo-500/5",
            },
            {
              icon: "🎯",
              title: "Trace-normalized regularization is important",
              desc: "With 630 features (vs 130), fixed λ=1e-6 would under-regularize. Trace normalization keeps the condition number under control.",
              color: "border-violet-500/20 bg-violet-500/5",
            },
          ].map((insight, i) => (
            <div key={i} className={`rounded-xl border p-4 ${insight.color}`}>
              <div className="text-lg mb-2">{insight.icon}</div>
              <div className="text-sm font-semibold text-white mb-1">{insight.title}</div>
              <div className="text-xs text-gray-400">{insight.desc}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function ScoreCard({
  label, score, tier, color, icon,
}: {
  label: string; score: string; tier: string; color: string; icon: string;
}) {
  const colorMap: Record<string, string> = {
    yellow: "border-yellow-500/30 bg-yellow-500/5 text-yellow-400",
    emerald: "border-emerald-500/30 bg-emerald-500/5 text-emerald-400",
    cyan: "border-cyan-500/30 bg-cyan-500/5 text-cyan-400",
  };
  return (
    <div className={`rounded-2xl border p-6 text-center ${colorMap[color]}`}>
      <div className="text-3xl mb-2">{icon}</div>
      <div className="text-xs text-gray-500 uppercase tracking-wider mb-1">{label}</div>
      <div className={`text-4xl font-bold font-mono mb-1 ${colorMap[color].split(" ")[2]}`}>{score}</div>
      <div className="text-xs text-gray-500">{tier}</div>
    </div>
  );
}

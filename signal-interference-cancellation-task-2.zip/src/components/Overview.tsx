import Card from "./ui/Card";
import SectionTitle from "./ui/SectionTitle";

export default function Overview() {
  return (
    <div className="space-y-8">
      <SectionTitle
        title="Problem Overview"
        subtitle="A physical device transmits and receives signals simultaneously. The RX signal is corrupted by structured interference from the device's own TX — plus an external source."
      />

      {/* Device diagram */}
      <Card>
        <h3 className="text-lg font-semibold text-white mb-6 flex items-center gap-2">
          <span>📡</span> Device Architecture
        </h3>
        <div className="relative flex items-center justify-center py-8">
          <div className="flex items-center gap-0 w-full max-w-2xl">
            {/* TX side */}
            <div className="flex flex-col items-end gap-3 w-48">
              {[
                { label: "TX[0]", sub: "Carrier A · High", color: "bg-cyan-500" },
                { label: "TX[1]", sub: "Carrier B · High", color: "bg-cyan-500" },
                { label: "TX[2]", sub: "Carrier A · Med", color: "bg-indigo-500" },
                { label: "TX[3]", sub: "Carrier B · Med", color: "bg-indigo-500" },
                { label: "TX[4]", sub: "Carrier A · Low", color: "bg-violet-500" },
                { label: "TX[5]", sub: "Carrier B · Low", color: "bg-violet-500" },
              ].map((ch) => (
                <div key={ch.label} className="flex items-center gap-2">
                  <div className="text-right">
                    <div className="text-sm font-mono font-bold text-white">{ch.label}</div>
                    <div className="text-xs text-gray-500">{ch.sub}</div>
                  </div>
                  <div className={`w-2 h-2 rounded-full ${ch.color}`} />
                </div>
              ))}
            </div>

            {/* Arrows TX → Device */}
            <div className="flex flex-col items-center justify-center h-full px-2">
              <div className="flex flex-col gap-3">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="flex items-center">
                    <div className="w-8 h-0.5 bg-gradient-to-r from-cyan-500 to-gray-600" />
                    <div className="w-0 h-0 border-t-4 border-b-4 border-l-4 border-t-transparent border-b-transparent border-l-gray-500" />
                  </div>
                ))}
              </div>
            </div>

            {/* Device box */}
            <div className="flex-1 mx-4">
              <div className="border-2 border-gray-600 rounded-xl bg-gray-800/60 p-5 text-center relative">
                <div className="text-sm font-semibold text-gray-300 mb-1">Physical Device</div>
                <div className="text-xs text-gray-500">7.68 MHz · 320 ms</div>
                {/* Interference leak indicator */}
                <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center">
                  <div className="w-0.5 h-4 bg-red-500/60" />
                  <div className="text-xs text-red-400 font-medium mt-1">↕ Interference leaks</div>
                </div>
              </div>
            </div>

            {/* Arrows Device → RX */}
            <div className="flex flex-col items-center justify-center h-full px-2">
              <div className="flex flex-col gap-5">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="flex items-center">
                    <div className="w-0 h-0 border-t-4 border-b-4 border-r-4 border-t-transparent border-b-transparent border-r-gray-500" />
                    <div className="w-8 h-0.5 bg-gradient-to-r from-gray-600 to-red-500" />
                  </div>
                ))}
              </div>
            </div>

            {/* RX side */}
            <div className="flex flex-col gap-5 w-40">
              {["RX[0]", "RX[1]", "RX[2]", "RX[3]"].map((ch) => (
                <div key={ch} className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-red-500" />
                  <div>
                    <div className="text-sm font-mono font-bold text-white">{ch}</div>
                    <div className="text-xs text-gray-500">corrupted</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Card>

      {/* Key stats grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          icon="🎯"
          title="Interference Model"
          value="IMD3"
          subtitle="3rd-order intermodulation distortion products"
          color="cyan"
        />
        <MetricCard
          icon="🌐"
          title="External Source"
          value="Rank-1"
          subtitle="Spatially coherent across all 4 RX channels"
          color="indigo"
        />
        <MetricCard
          icon="📐"
          title="Model Features"
          value="30 × 21"
          subtitle="Cross-product terms × temporal lags"
          color="violet"
        />
        <MetricCard
          icon="📊"
          title="Scoring Band"
          value="1.9 MHz"
          subtitle="±0.3 MHz band where interference is concentrated"
          color="emerald"
        />
      </div>

      {/* Scoring explanation */}
      <Card>
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <span>🏆</span> Scoring Metric
        </h3>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <p className="text-gray-300 text-sm mb-4">
              The score measures interference <strong className="text-white">power reduction</strong> in a narrow
              1.6 MHz band (1.9 MHz ± 0.3 MHz) where the interference is concentrated:
            </p>
            <div className="bg-gray-800/60 rounded-xl p-4 font-mono text-sm border border-gray-700">
              <div className="text-cyan-400">score = (1/4) · Σ reduction(c)</div>
              <div className="text-gray-300 mt-2">
                reduction(c) = 10·log₁₀(<span className="text-emerald-400">P₀</span> / <span className="text-red-400">P₁</span>)
              </div>
            </div>
          </div>
          <div className="space-y-3">
            {[
              { tier: "No cancellation", score: "0 dB", color: "text-red-400", bg: "bg-red-500/10 border-red-500/20" },
              { tier: "Baseline (provided)", score: "~4 dB", color: "text-yellow-400", bg: "bg-yellow-500/10 border-yellow-500/20" },
              { tier: "Good", score: "> 8 dB", color: "text-emerald-400", bg: "bg-emerald-500/10 border-emerald-500/20" },
              { tier: "This solution (target)", score: "> 8 dB", color: "text-cyan-400", bg: "bg-cyan-500/10 border-cyan-500/20" },
            ].map((row) => (
              <div key={row.tier} className={`flex justify-between items-center px-4 py-2 rounded-lg border ${row.bg}`}>
                <span className="text-sm text-gray-300">{row.tier}</span>
                <span className={`font-bold font-mono ${row.color}`}>{row.score}</span>
              </div>
            ))}
          </div>
        </div>
      </Card>

      {/* Validity constraint */}
      <Card className="border-amber-500/30 bg-amber-500/5">
        <h3 className="text-lg font-semibold text-amber-300 mb-3 flex items-center gap-2">
          <span>⚠️</span> Validity Constraint
        </h3>
        <p className="text-gray-300 text-sm mb-4">
          The scorer enforces that the removed component must be largely explainable as a combination of:
        </p>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="bg-gray-800/40 rounded-lg p-4 border border-amber-500/20">
            <div className="text-amber-400 font-semibold mb-1">① TX-driven component</div>
            <div className="text-gray-400 text-sm">
              &gt; 95% of the removed power must come from nonlinear TX cross-products
            </div>
          </div>
          <div className="bg-gray-800/40 rounded-lg p-4 border border-amber-500/20">
            <div className="text-amber-400 font-semibold mb-1">② Rank-1 spatial component</div>
            <div className="text-gray-400 text-sm">
              Remaining component must be rank-1 (shared waveform × per-channel scaling)
            </div>
          </div>
        </div>
        <p className="text-gray-400 text-xs mt-4">
          Our two-stage pipeline directly satisfies both constraints by design.
        </p>
      </Card>
    </div>
  );
}

function MetricCard({
  icon, title, value, subtitle, color,
}: {
  icon: string; title: string; value: string; subtitle: string; color: string;
}) {
  const colorMap: Record<string, string> = {
    cyan: "text-cyan-400 bg-cyan-500/10 border-cyan-500/20",
    indigo: "text-indigo-400 bg-indigo-500/10 border-indigo-500/20",
    violet: "text-violet-400 bg-violet-500/10 border-violet-500/20",
    emerald: "text-emerald-400 bg-emerald-500/10 border-emerald-500/20",
  };
  return (
    <div className={`rounded-xl border p-4 ${colorMap[color]}`}>
      <div className="text-2xl mb-2">{icon}</div>
      <div className="text-xs text-gray-500 uppercase tracking-wider mb-1">{title}</div>
      <div className={`text-2xl font-bold font-mono mb-1 ${colorMap[color].split(" ")[0]}`}>{value}</div>
      <div className="text-xs text-gray-400">{subtitle}</div>
    </div>
  );
}

export default function Footer() {
  return (
    <footer className="border-t border-gray-700/50 bg-gray-900/50 mt-16">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid md:grid-cols-3 gap-6">
          <div>
            <div className="text-sm font-semibold text-white mb-2">Solution</div>
            <div className="text-xs text-gray-500 space-y-1">
              <div>Two-stage interference cancellation</div>
              <div>Stage 1: Extended IMD3 (30 terms, ±10 lags)</div>
              <div>Stage 2: Rank-1 PCA external source removal</div>
            </div>
          </div>
          <div>
            <div className="text-sm font-semibold text-white mb-2">Quick Start</div>
            <div className="font-mono text-xs text-gray-500 space-y-1">
              <div className="text-emerald-400">pip install numpy scipy gdown</div>
              <div className="text-cyan-400">python applicant_solution.py</div>
            </div>
          </div>
          <div>
            <div className="text-sm font-semibold text-white mb-2">Files</div>
            <div className="text-xs text-gray-500 space-y-1">
              <div><span className="text-cyan-400">applicant_solution.py</span> — main entry point</div>
              <div><span className="text-yellow-400">results.json</span> — output scores</div>
              <div><span className="text-emerald-400">SOLUTION.md</span> — full report</div>
            </div>
          </div>
        </div>
        <div className="border-t border-gray-800 mt-6 pt-4 flex justify-between items-center">
          <div className="text-xs text-gray-600">
            Signal Interference Cancellation — Applicant Solution
          </div>
          <div className="flex items-center gap-2 text-xs text-gray-600">
            <span>Target:</span>
            <span className="text-emerald-400 font-mono font-bold">&gt; 8 dB</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

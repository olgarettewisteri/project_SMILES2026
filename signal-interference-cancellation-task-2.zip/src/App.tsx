import { useState } from "react";
import Header from "./components/Header";
import Overview from "./components/Overview";
import SignalModel from "./components/SignalModel";
import Pipeline from "./components/Pipeline";
import Stage1 from "./components/Stage1";
import Stage2 from "./components/Stage2";
import Results from "./components/Results";
import CodeViewer from "./components/CodeViewer";
import Footer from "./components/Footer";
import type { Tab } from "./types";

const TABS: { id: Tab; label: string; icon: string }[] = [
  { id: "overview", label: "Overview", icon: "🎯" },
  { id: "model", label: "Signal Model", icon: "📡" },
  { id: "pipeline", label: "Pipeline", icon: "🔧" },
  { id: "stage1", label: "Stage 1: TX", icon: "⚡" },
  { id: "stage2", label: "Stage 2: Spatial", icon: "🌐" },
  { id: "results", label: "Results", icon: "📊" },
  { id: "code", label: "Code", icon: "💻" },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>("overview");

  return (
    <div className="min-h-screen bg-gray-950 text-gray-100">
      <Header />

      {/* Tab Navigation */}
      <nav className="sticky top-0 z-40 bg-gray-900/95 backdrop-blur border-b border-gray-700/50 shadow-xl">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex overflow-x-auto scrollbar-hide gap-1 py-2">
            {TABS.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm whitespace-nowrap transition-all duration-200 ${
                  activeTab === tab.id
                    ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 shadow-lg shadow-cyan-500/10"
                    : "text-gray-400 hover:text-gray-200 hover:bg-gray-800"
                }`}
              >
                <span>{tab.icon}</span>
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {activeTab === "overview" && <Overview />}
        {activeTab === "model" && <SignalModel />}
        {activeTab === "pipeline" && <Pipeline />}
        {activeTab === "stage1" && <Stage1 />}
        {activeTab === "stage2" && <Stage2 />}
        {activeTab === "results" && <Results />}
        {activeTab === "code" && <CodeViewer />}
      </main>

      <Footer />
    </div>
  );
}
